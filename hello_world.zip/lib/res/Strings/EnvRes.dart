import 'package:flutter/material.dart';

class EnvRes {
  static String loginReq = "logingreq";
  static String restrationReq = "RegistrationReq";
  static String reqMyUserInfo = "ReqMyUserInfo";
  static String reqLatestNews = "ReqLatestNews";
  static String sendmsgreq = 'SendMsgReq';
  static String reqcalendarInfo = 'ReqCalendarInfo';
  static String reqCourseItems = 'ReqCourseItems';
  static String reqcourseDocs = 'ReqCourseDocs';

  // static String serverAddress = "192.168.1.15";
  static String serverAddress = "152.67.111.34";

  static int serverPort = 65400;

  static Color drwerMenuItemColor = Colors.blueGrey.shade900;
  static Color appBarColor = Colors.blueGrey.shade900;

  static Color dashboardHeadColor = Colors.blueGrey.shade900;

  static Color bottomNavColor = Colors.blueGrey.shade900;
  static Color themeColor = Colors.blueGrey.shade900;
}
