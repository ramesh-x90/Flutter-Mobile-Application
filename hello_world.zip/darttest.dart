import 'dart:core';

void main() {
  String st = "i am ramesh shyaman";
  List a = st.split(' ');
  print(a.getRange(0, 2));
}
